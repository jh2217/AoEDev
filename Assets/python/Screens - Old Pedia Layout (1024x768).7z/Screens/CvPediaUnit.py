## Sid Meier's Civilization 4
## Copyright Firaxis Games 2005
from CvPythonExtensions import *
import CvUtil
import ScreenInput
import CvScreenEnums

# globals
gc = CyGlobalContext()
ArtFileMgr = CyArtFileMgr()
localText = CyTranslator()

class CvPediaUnit:
	"Civilopedia Screen for Units"

	def __init__(self, main):
		self.iUnit = -1
		self.top = main

		self.X_UNIT_PANE = 20
		self.Y_UNIT_PANE = 70
		self.W_UNIT_PANE = 433
		self.H_UNIT_PANE = 210

		self.X_UNIT_ANIMATION = 475
		self.Y_UNIT_ANIMATION = 78
		self.W_UNIT_ANIMATION = 303
		self.H_UNIT_ANIMATION = 200
		self.X_ROTATION_UNIT_ANIMATION = -20
		self.Z_ROTATION_UNIT_ANIMATION = 30
		self.SCALE_ANIMATION = 1.0

		self.X_ICON = 48
		self.Y_ICON = 105
		self.W_ICON = 150
		self.H_ICON = 150
		self.ICON_SIZE = 64

		self.BUTTON_SIZE = 64
		self.PROMOTION_ICON_SIZE = 32

		self.X_STATS_PANE = 210
		self.Y_STATS_PANE = 145
		self.W_STATS_PANE = 250
		self.H_STATS_PANE = 200

		self.X_SPECIAL_PANE = 20
		self.Y_SPECIAL_PANE = 420
		self.W_SPECIAL_PANE = 433
		self.H_SPECIAL_PANE = 144

		self.X_PREREQ_PANE = 20
		self.Y_PREREQ_PANE = 292
		self.W_PREREQ_PANE = 433
		self.H_PREREQ_PANE = 124

		self.X_UPGRADES_TO_PANE = 475
		self.Y_UPGRADES_TO_PANE = 292
		self.W_UPGRADES_TO_PANE = 303
		self.H_UPGRADES_TO_PANE = 124

		self.X_PROMO_PANE = 20
		self.Y_PROMO_PANE = 574
		self.W_PROMO_PANE = 433
		self.H_PROMO_PANE = 124

		self.X_HISTORY_PANE = 475
		self.Y_HISTORY_PANE = 420
		self.W_HISTORY_PANE = 303
		self.H_HISTORY_PANE = 278

		self.FILTERS =	[
			{
				"name" : "UnFiltered",		# Name of the filter as it appears in dropdown menu.  Needs to be unique for this screen
				"Purpose" : "Clears all currently active filters",		# Description for the sanity of those who modify this file, appears and is used nowhere else
				"TypeHardcoded" : False,		# If this is True, then only those items in the HardcodeList will pass the check
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,		# If this is True, then only those items in the HardcodeList will pass the check
				"ClassHardcodeList" : [],
				"Value to Check" : 'None',	# Note that eUnit is the UnitInfo object being tested
				"Desired Result" : 'None',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "Heroes",
				"Purpose" : "World Units only",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'isWorldUnitClass(eUnit.getUnitClassType())',
				"Desired Result" : 'True',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "National Units",
				"Purpose" : "National Limited Units only (T4)",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'isNationalUnitClass(eUnit.getUnitClassType()) or isTeamUnitClass(eUnit.getUnitClassType())',
				"Desired Result" : 'True',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "Unbuildable",
				"Purpose" : "Simple approach, but should cover most all cases",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'eUnit.getProductionCost() < 0 or eUnit.getMinLevel() > 0',
				"Desired Result" : 'True',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "Buildable",
				"Purpose" : "Simple approach, but should cover most all cases",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'eUnit.getProductionCost() < 0 or eUnit.getMinLevel() > 0',
				"Desired Result" : 'False',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "Starting Units",
				"Purpose" : "Test for the Hardcoded Unit List primarily",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : True,
				"ClassHardcodeList" : [
					'UNITCLASS_SETTLER',
					'UNITCLASS_SCOUT',
					'UNITCLASS_WARRIOR'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "Default Units",
				"Purpose" : "All Units which don't require a certain Civ",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getUnitClassInfo(eUnit.getUnitClassType()).getDefaultUnitIndex() != iUnit or gc.getUnitClassInfo(eUnit.getUnitClassType()).isUnique()',
				"Desired Result" : 'False',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "Civ Specific",
				"Purpose" : "All Units which require a certain Civ",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getUnitClassInfo(eUnit.getUnitClassType()).getDefaultUnitIndex() != iUnit or gc.getUnitClassInfo(eUnit.getUnitClassType()).isUnique()',
				"Desired Result" : 'True',
				"Primary" : True,
				"Specific Civ" : False,
			},
			{
				"name" : "  Amurite Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_AMURITES")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Archos Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_ARCHOS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Austerin Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_AUSTERIN")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Balseraph Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_BALSERAPHS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Bannor Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_BANNOR")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Calabim Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_CALABIM")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Chislev Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_CHISLEV")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Clan of Embers Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_CLAN_OF_EMBERS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Cualli Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_CUALLI")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Doviello Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_DOVIELLO")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Dural Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_DURAL")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Elohim Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_ELOHIM")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Frozen Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_FROZEN")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Grigori Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_GRIGORI")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Hippus Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_HIPPUS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Jotnar Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_JOTNAR")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Illian Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_ILLIANS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Infernal Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_INFERNAL")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Khazad Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_KHAZAD")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Kuriotates Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_KURIOTATES")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Lanun Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_LANUN")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Ljosalfar Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_LJOSALFAR")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Luchuirp Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_LUCHUIRP")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Malakim Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_MALAKIM")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Mazatl Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_MAZATL")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Mechanos Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_MECHANOS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Mercurian Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_MERCURIANS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Scion Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_SCIONS")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Sheaim Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_SHEAIM")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Sidar Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_SIDAR")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Svartalfar Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_SVARTALFAR")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  The Legion of D'tesh Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_DTESH")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Orcish Savage Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_ORC")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Animal Pack Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_ANIMAL")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			{
				"name" : "  Demonic Horde Units",
				"Purpose" : "Civ Specific Cases, massive PITA to just write all these in...",
				"TypeHardcoded" : False,
				"TypeHardcodeList" : [],
				"ClassHardcoded" : False,
				"ClassHardcodeList" : [],
				"Value to Check" : 'gc.getCivilizationInfo(gc.getInfoTypeForString("CIVILIZATION_DEMON")).getCivilizationUnits(eUnit.getUnitClassType()) == iUnit',
				"Desired Result" : 'True',
				"Primary" : False,
				"Specific Civ" : True,
			},
			]

		# List the filters which you want to be available initially, or self.FILTERS to have all of them available from the start
		self.ALLOWED_FILTERS = []
		for i, filter in enumerate(self.FILTERS):
			if self.FILTERS[i]["Primary"]:
				self.ALLOWED_FILTERS.append(self.FILTERS[i])
		self.CURRENT_FILTER = self.FILTERS[0]

		self.SORTS =	[
			{
				"name" : "Sort by Alphabet",
				"Purpose" : "Default Sorting Method",
				"Value to Sort" : 'eUnit.getDescription()',
			},
			{
				"name" : "Sort by Cost",
				"Purpose" : "Be nice if all sorts were so easy to decide on",
				"Value to Sort" : '-eUnit.getProductionCost()',
			},
			{
				"name" : "Sort by Attack Strength",
				"Purpose" : "Though this doesn't account for affinity and other such bonuses",
				"Value to Sort" : '-eUnit.getCombat()',
			},
			{
				"name" : "Sort by Defense Strength",
				"Purpose" : "Again, doesn't count for starting promotion bonuses and other such goodies",
				"Value to Sort" : '-eUnit.getCombatDefense()',
			},
			{
				"name" : "Sort by Ranged Strength",
				"Purpose" : "But these are still nice, even without the extra checks IMO",
				"Value to Sort" : '-eUnit.getAirCombat()',
			},
			{
				"name" : "Sort by Collateral Damage",
				"Purpose" : "Maybe sorting by limit would be better here, but could do that ALSO if someone wanted...",
				"Value to Sort" : '-eUnit.getCollateralDamage()',
			},
			{
				"name" : "Sort by UnitCombat",
				"Purpose" : "To pair with filtering by UnitCombat, though useless when together ;)",
				"Value to Sort" : 'eUnit.getUnitCombatType()',
			},
			{
				"name" : "Sort by Domain",
				"Purpose" : "Not sure how used this one will be",
				"Value to Sort" : 'eUnit.getDomainType()',
			},
			{
				"name" : "Sort by XML Order",
				"Purpose" : "Default, unsorted method",
				"Value to Sort" : None,
			},
			]

		# List the sorts which you want to be available initially, or self.SORTS to have all of them available from the start
		self.ALLOWED_SORTS = self.SORTS
		self.CURRENT_SORT = self.SORTS[0]
		self.SUB_SORT = self.SORTS[0]

	# Screen construction function
	def interfaceScreen(self, iUnit):
		self.iUnit = iUnit

		self.top.deleteAllWidgets()

		screen = self.top.getScreen()

		bNotActive = (not screen.isActive())
		if bNotActive:
			self.top.setPediaCommonWidgets()

		#Filter/Sort dropdowns
		self.top.FILTER_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.FILTER_DROPDOWN_ID, 22, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, filter in enumerate(self.ALLOWED_FILTERS):
			screen.addPullDownString(self.top.FILTER_DROPDOWN_ID, filter["name"], i, i, filter == self.CURRENT_FILTER )

		self.top.SORT_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.SORT_DROPDOWN_ID, 700, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, sort in enumerate(self.ALLOWED_SORTS):
			screen.addPullDownString(self.top.SORT_DROPDOWN_ID, sort["name"], 1, 1, sort == self.CURRENT_SORT )

		# Header...
		szHeader = u"<font=4b>" + gc.getUnitInfo(self.iUnit).getDescription().upper() + u"</font>"
		TopPage = CivilopediaPageTypes.CIVILOPEDIA_PAGE_UNIT
		screen.setLabel(self.top.getNextWidgetName(), "Background", szHeader, CvUtil.FONT_CENTER_JUSTIFY, self.top.X_SCREEN, self.top.Y_TITLE, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_GENERAL, TopPage, iUnit)

		# Top
		screen.setText(self.top.getNextWidgetName(), "Background", self.top.MENU_TEXT, CvUtil.FONT_LEFT_JUSTIFY, self.top.X_MENU, self.top.Y_MENU, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_PEDIA_MAIN, TopPage, -1)

		if self.top.iLastScreen	!= CvScreenEnums.PEDIA_UNIT or bNotActive:
			self.placeLinks(true)
			self.top.iLastScreen = CvScreenEnums.PEDIA_UNIT
		else:
			self.placeLinks(false)

		# Icon
		screen.addPanel( self.top.getNextWidgetName(), "", "", False, False,
			self.X_UNIT_PANE, self.Y_UNIT_PANE, self.W_UNIT_PANE, self.H_UNIT_PANE, PanelStyles.PANEL_STYLE_BLUE50)
		screen.addPanel(self.top.getNextWidgetName(), "", "", false, false,
			self.X_ICON, self.Y_ICON, self.W_ICON, self.H_ICON, PanelStyles.PANEL_STYLE_MAIN)
		szButton = gc.getUnitInfo(self.iUnit).getButton()
		if self.top.iActivePlayer != -1:
			szButton = gc.getPlayer(self.top.iActivePlayer).getUnitButton(self.iUnit)
		screen.addDDSGFC(self.top.getNextWidgetName(), szButton,
			self.X_ICON + self.W_ICON/2 - self.ICON_SIZE/2, self.Y_ICON + self.H_ICON/2 - self.ICON_SIZE/2, self.ICON_SIZE, self.ICON_SIZE, WidgetTypes.WIDGET_GENERAL, -1, -1 )

		if isWorldUnitClass(gc.getUnitInfo(iUnit).getUnitClassType()):
			szImage = str(gc.getUnitInfo(iUnit).getImage())
			screen.addDDSGFC(self.top.getNextWidgetName(), szImage,
				self.X_UPGRADES_TO_PANE, self.Y_UPGRADES_TO_PANE, self.W_UPGRADES_TO_PANE, self.H_UPGRADES_TO_PANE, WidgetTypes.WIDGET_GENERAL, -1, -1 )

		# Unit animation
		screen.addUnitGraphicGFC(self.top.getNextWidgetName(), self.iUnit, self.X_UNIT_ANIMATION, self.Y_UNIT_ANIMATION, self.W_UNIT_ANIMATION, self.H_UNIT_ANIMATION, WidgetTypes.WIDGET_GENERAL, -1, -1, self.X_ROTATION_UNIT_ANIMATION, self.Z_ROTATION_UNIT_ANIMATION, self.SCALE_ANIMATION, True)

		self.placeStats()

		self.placeUpgradesTo()

		self.placeRequires()

		self.placeSpecial()

		self.placePromotions()

		self.placeHistory()

	# Place strength/movement
	def placeStats(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()

		# Unit combat group
		iCombatType = gc.getUnitInfo(self.iUnit).getUnitCombatType()
		if (iCombatType != -1):
			screen.setImageButton(self.top.getNextWidgetName(), gc.getUnitCombatInfo(iCombatType).getButton(), self.X_STATS_PANE, self.Y_STATS_PANE - 60, 32, 32, WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT_COMBAT, iCombatType, 0)
			screen.setText(self.top.getNextWidgetName(), "", u"<font=3>" + gc.getUnitCombatInfo(iCombatType).getDescription() + u"</font>", CvUtil.FONT_LEFT_JUSTIFY, self.X_STATS_PANE + 37, self.Y_STATS_PANE - 55, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT_COMBAT, iCombatType, 0)

		screen.addListBoxGFC(panelName, "", self.X_STATS_PANE, self.Y_STATS_PANE - 20, self.W_STATS_PANE, self.H_STATS_PANE + 20, TableStyles.TABLE_STYLE_EMPTY)
		screen.enableSelect(panelName, False)

		if (gc.getUnitInfo(self.iUnit).getAirRange() > 0):
			szRanged = localText.getText("TXT_KEY_PEDIA_RANGED", ( gc.getUnitInfo(self.iUnit).getAirCombat(), ) )
			if (gc.getUnitInfo(self.iUnit).getAirCombatLimit() == 100):
				screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szRanged.upper() + u"%c" % CyGame().getSymbolID(FontSymbols.RANGED_CHAR) + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)
			else:
				screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szRanged.upper() + u"%c<color=255,255,0>%d%%</color>" % (CyGame().getSymbolID(FontSymbols.RANGED_CHAR),gc.getUnitInfo(self.iUnit).getAirCombatLimit()) + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)

		iStrength = gc.getUnitInfo(self.iUnit).getCombat()

		szName = self.top.getNextWidgetName()

		if iStrength == gc.getUnitInfo(self.iUnit).getCombatDefense():
			szStrength = localText.getText("TXT_KEY_PEDIA_STRENGTH", ( iStrength, ) )
		else:
			szStrength = localText.getText("TXT_KEY_PEDIA_STRENGTH_DEFENSE", ( iStrength, gc.getUnitInfo(self.iUnit).getCombatDefense()) )

		if(gc.getUnitInfo(self.iUnit).getCombatLimit() == gc.getMAX_HIT_POINTS()):
			screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szStrength.upper() + u"%c" % CyGame().getSymbolID(FontSymbols.STRENGTH_CHAR) + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)
		else:
			screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szStrength.upper() + u"%c<color=255,255,0>%d%%</color>" % (CyGame().getSymbolID(FontSymbols.STRENGTH_CHAR),gc.getUnitInfo(self.iUnit).getCombatLimit() / gc.getDefineINT("HIT_POINT_FACTOR")) + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)

		szName = self.top.getNextWidgetName()
		szMovement = localText.getText("TXT_KEY_PEDIA_MOVEMENT", ( gc.getUnitInfo(self.iUnit).getMoves(), ) )
		screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szMovement.upper() + u"%c" % CyGame().getSymbolID(FontSymbols.MOVES_CHAR) + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)

		if (gc.getUnitInfo(self.iUnit).getProductionCost() >= 0 and not gc.getUnitInfo(self.iUnit).isFound()):
			szName = self.top.getNextWidgetName()
			if self.top.iActivePlayer == -1:
				szCost = localText.getText("TXT_KEY_PEDIA_COST", ((gc.getUnitInfo(self.iUnit).getProductionCost() * gc.getDefineINT("UNIT_PRODUCTION_PERCENT"))/100,))
			else:
				szCost = localText.getText("TXT_KEY_PEDIA_COST", ( gc.getActivePlayer().getUnitProductionNeeded(self.iUnit), ) )
			screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szCost.upper() + u"%c" % gc.getYieldInfo(YieldTypes.YIELD_PRODUCTION).getChar() + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)

		if (gc.getUnitInfo(self.iUnit).getAirRange() > 0):
			szName = self.top.getNextWidgetName()
			szRange = localText.getText("TXT_KEY_PEDIA_RANGE", ( gc.getUnitInfo(self.iUnit).getAirRange(), ) )
			screen.appendListBoxStringNoUpdate(panelName, u"<font=4>" + szRange.upper() + u"</font>", WidgetTypes.WIDGET_GENERAL, 0, 0, CvUtil.FONT_LEFT_JUSTIFY)

		screen.updateListBox(panelName)

	# Place prereqs (techs, resources)
	def placeRequires(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_REQUIRES", ()), "", false, true, self.X_PREREQ_PANE, self.Y_PREREQ_PANE, self.W_PREREQ_PANE, self.H_PREREQ_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		screen.attachLabel(panelName, "", "  ")

		# add tech buttons
		iPrereq = gc.getUnitInfo(self.iUnit).getPrereqAndTech()
		if (iPrereq >= 0):
			screen.attachImageButton( panelName, "", gc.getTechInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_TECH, iPrereq, 1, False )

		for j in range(gc.getDefineINT("NUM_UNIT_AND_TECH_PREREQS")):
			iPrereq = gc.getUnitInfo(self.iUnit).getPrereqAndTechs(j)
			if (iPrereq >= 0):
				screen.attachImageButton( panelName, "", gc.getTechInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_TECH, iPrereq, -1, False )

		# add resource buttons
		bFirst = True
		iPrereq = gc.getUnitInfo(self.iUnit).getPrereqAndBonus()
		if (iPrereq >= 0):
			bFirst = False
			screen.attachImageButton( panelName, "", gc.getBonusInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_BONUS, iPrereq, -1, False )

		# count the number of OR resources
		nOr = 0
		for j in range(gc.getNUM_UNIT_PREREQ_OR_BONUSES()):
			if (gc.getUnitInfo(self.iUnit).getPrereqOrBonuses(j) > -1):
				nOr += 1

		szLeftDelimeter = ""
		szRightDelimeter = ""
		#  Display a bracket if we have more than one OR resource and an AND resource
		if (not bFirst):
			if (nOr > 1):
				szLeftDelimeter = localText.getText("TXT_KEY_AND", ()) + "( "
				szRightDelimeter = " ) "
			elif (nOr > 0):
				szLeftDelimeter = localText.getText("TXT_KEY_AND", ())

		if len(szLeftDelimeter) > 0:
			screen.attachLabel(panelName, "", szLeftDelimeter)

		bFirst = True
		for j in range(gc.getNUM_UNIT_PREREQ_OR_BONUSES()):
			eBonus = gc.getUnitInfo(self.iUnit).getPrereqOrBonuses(j)
			if (eBonus > -1):
				if (not bFirst):
					screen.attachLabel(panelName, "", localText.getText("TXT_KEY_OR", ()))
				else:
					bFirst = False
				screen.attachImageButton( panelName, "", gc.getBonusInfo(eBonus).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_BONUS, eBonus, -1, False )

		if len(szRightDelimeter) > 0:
			screen.attachLabel(panelName, "", szRightDelimeter)

		# add religion buttons
		iPrereq = gc.getUnitInfo(self.iUnit).getPrereqReligion()
		if (iPrereq >= 0):
			screen.attachImageButton( panelName, "", gc.getReligionInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_RELIGION, iPrereq, -1, False )

		# add building buttons
		iPrereq = gc.getUnitInfo(self.iUnit).getPrereqBuilding()
		if (iPrereq >= 0):
			screen.attachImageButton( panelName, "", gc.getBuildingInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_BUILDING, iPrereq, -1, False )

		iPrereq = gc.getUnitInfo(self.iUnit).getPrereqBuildingClass()
		if (iPrereq >= 0):
			iPrereq = gc.getBuildingClassInfo(iPrereq).getDefaultBuildingIndex()
			screen.attachImageButton( panelName, "", gc.getBuildingInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_BUILDING, iPrereq, -1, False )

		iPrereq = gc.getUnitInfo(self.iUnit).getPrereqCivic()
		if (iPrereq >= 0):
			screen.attachImageButton( panelName, "", gc.getCivicInfo(iPrereq).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_CIVIC, iPrereq, -1, False )

	# Place upgrades
	def placeUpgradesTo(self):
		if isWorldUnitClass(gc.getUnitInfo(self.iUnit).getUnitClassType()) == False:

			screen = self.top.getScreen()

			panelName = self.top.getNextWidgetName()
			screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_UPGRADES_TO", ()), "", false, true, self.X_UPGRADES_TO_PANE, self.Y_UPGRADES_TO_PANE, self.W_UPGRADES_TO_PANE, self.H_UPGRADES_TO_PANE, PanelStyles.PANEL_STYLE_BLUE50)

			screen.attachLabel(panelName, "", "  ")

			for k in range(gc.getUnitInfo(self.iUnit).getNumUpgradeUnitClass()):
				eClass = gc.getUnitInfo(self.iUnit).getUpgradeUnitClass(k)
				if self.top.iActivePlayer == -1:
					eLoopUnit = gc.getUnitClassInfo(eClass).getDefaultUnitIndex()
				else:
					eLoopUnit = gc.getCivilizationInfo(gc.getGame().getActiveCivilizationType()).getCivilizationUnits(eClass)

				if (eLoopUnit >= 0 and gc.getUnitInfo(eLoopUnit).isDisableUpgradeTo() == False):
					szButton = gc.getUnitInfo(eLoopUnit).getButton()
					if self.top.iActivePlayer != -1:
						szButton = gc.getPlayer(self.top.iActivePlayer).getUnitButton(eLoopUnit)
					screen.attachImageButton( panelName, "", szButton, GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT, eLoopUnit, 1, False )

	# Place Special abilities
	def placeSpecial(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_SPECIAL_ABILITIES", ()), "", true, false,
								self.X_SPECIAL_PANE, self.Y_SPECIAL_PANE, self.W_SPECIAL_PANE, self.H_SPECIAL_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		listName = self.top.getNextWidgetName()

		szSpecialText = CyGameTextMgr().getUnitHelp( self.iUnit, True, False, False, None )[1:]
		screen.addMultilineText(listName, szSpecialText, self.X_SPECIAL_PANE+5, self.Y_SPECIAL_PANE+30, self.W_SPECIAL_PANE-10, self.H_SPECIAL_PANE-35, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY)

	def placeHistory(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_CIVILOPEDIA_HISTORY", ()), "", True, True,
						self.X_HISTORY_PANE, self.Y_HISTORY_PANE,
						self.W_HISTORY_PANE, self.H_HISTORY_PANE,
						PanelStyles.PANEL_STYLE_BLUE50 )

		textName = self.top.getNextWidgetName()
		szText = u""
		if len(gc.getUnitInfo(self.iUnit).getStrategy()) > 0:
			szText += localText.getText("TXT_KEY_CIVILOPEDIA_STRATEGY", ())
			szText += gc.getUnitInfo(self.iUnit).getStrategy()
			szText += u"\n\n"
		szText += localText.getText("TXT_KEY_CIVILOPEDIA_BACKGROUND", ())
		szText += gc.getUnitInfo(self.iUnit).getCivilopedia()
		screen.addMultilineText( textName, szText, self.X_HISTORY_PANE + 15, self.Y_HISTORY_PANE + 40,
			self.W_HISTORY_PANE - (15 * 2), self.H_HISTORY_PANE - (15 * 2) - 25, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY)

	def placePromotions(self):
		screen = self.top.getScreen()

		# add pane and text
		panelName = self.top.getNextWidgetName()
		screen.addPanel(panelName, localText.getText("TXT_KEY_PEDIA_CATEGORY_PROMOTION", ()), "", true, true, self.X_PROMO_PANE, self.Y_PROMO_PANE, self.W_PROMO_PANE, self.H_PROMO_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		# add promotion buttons
		rowListName = self.top.getNextWidgetName()
		screen.addMultiListControlGFC(rowListName, "", self.X_PROMO_PANE+15, self.Y_PROMO_PANE+40, self.W_PROMO_PANE-20, self.H_PROMO_PANE-40, 1, self.PROMOTION_ICON_SIZE, self.PROMOTION_ICON_SIZE, TableStyles.TABLE_STYLE_STANDARD)

		for k in range(gc.getNumPromotionInfos()):
			if (isPromotionValid(k, self.iUnit, false) and not gc.getPromotionInfo(k).isGraphicalOnly()):
				screen.appendMultiListButton( rowListName, gc.getPromotionInfo(k).getButton(), 0, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, k, -1, false )

	def placeLinks(self, bRedraw):
		screen = self.top.getScreen()

		if bRedraw:
			screen.clearListBoxGFC(self.top.LIST_ID)

		listSorted = self.getSortedList()

		i = 0
		iSelected = 0
		for iI in range(len(listSorted)):
			iUnit = listSorted[iI][2]
			szName = listSorted[iI][3]
			if bRedraw:
				screen.appendListBoxString(self.top.LIST_ID, szName, WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT, iUnit, -1, CvUtil.FONT_LEFT_JUSTIFY)
			if iUnit == self.iUnit:
				iSelected = i
			i += 1

		screen.setSelectedListBoxStringGFC(self.top.LIST_ID, iSelected)

	def getSortedList(self):
		listUnits = []
		iCount = 0
		for iUnit in range(gc.getNumUnitInfos()):
			eUnit = gc.getUnitInfo(iUnit)
			if not eUnit.isGraphicalOnly():
				if self.CURRENT_FILTER["TypeHardcoded"]:
					for unit in self.CURRENT_FILTER["TypeHardcodeList"]:
						if iUnit == gc.getInfoTypeForString(unit):
							listUnits.append(iUnit)
							iCount += 1
				elif self.CURRENT_FILTER["ClassHardcoded"]:
					for unitclass in self.CURRENT_FILTER["ClassHardcodeList"]:
						if gc.getUnitInfo(iUnit).getUnitClassType() == gc.getInfoTypeForString(unitclass):
							listUnits.append(iUnit)
							iCount += 1
				elif eval(self.CURRENT_FILTER["Value to Check"]) == eval(self.CURRENT_FILTER["Desired Result"]):
					listUnits.append(iUnit)
					iCount += 1

		listSorted = [(0,0,0,0,0,0)] * iCount
		iI = 0
		for iUnit in listUnits:
			eUnit = gc.getUnitInfo(iUnit)
			szButton = eUnit.getButton()
			if self.top.iActivePlayer != -1:
				szButton = gc.getPlayer(self.top.iActivePlayer).getUnitButton(iUnit)
			sort1 = 0
			sort2 = 0
			if not self.CURRENT_SORT["Value to Sort"] == None:
				sort1 = eval(self.CURRENT_SORT["Value to Sort"])
				if not self.SUB_SORT["Value to Sort"] == None:
					sort2 = eval(self.SUB_SORT["Value to Sort"])
			listSorted[iI] = (sort1, sort2, iUnit, eUnit.getDescription(), szButton, 1)
			iI += 1
		listSorted.sort()

		return listSorted

	def applyFilterSort(self, filter, sort):
		if not self.CURRENT_SORT == sort:
			self.SUB_SORT = self.CURRENT_SORT
			self.CURRENT_SORT = sort
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_UNIT, True)

		if not self.CURRENT_FILTER == filter:
			if filter["name"] == "Civ Specific" or filter["Specific Civ"]:
				self.ALLOWED_FILTERS = []
				for i, filterlist in enumerate(self.FILTERS):
					if filterlist["Specific Civ"] or filterlist["name"] == "Civ Specific" or filterlist["name"] == "UnFiltered":	#Things break if the item you use to get into a sublist is not also a part of that sublist
						self.ALLOWED_FILTERS.append(filterlist)
			elif (self.CURRENT_FILTER["Specific Civ"] and filter["Primary"]) or self.CURRENT_FILTER["name"] == "Civ Specific":
				self.ALLOWED_FILTERS = []
				for i, filterlist in enumerate(self.FILTERS):
					if filterlist["Primary"]:
						self.ALLOWED_FILTERS.append(filterlist)
			self.CURRENT_FILTER = filter
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_UNIT, True)

	# Will handle the input for this screen...
	def handleInput (self, inputClass):
		if (inputClass.getNotifyCode() == NotifyCode.NOTIFY_LISTBOX_ITEM_SELECTED):
			screen = self.top.getScreen()
			iFilterIndex = screen.getSelectedPullDownID(self.top.FILTER_DROPDOWN_ID)
			iSortIndex = screen.getSelectedPullDownID(self.top.SORT_DROPDOWN_ID)
			self.applyFilterSort(self.ALLOWED_FILTERS[iFilterIndex], self.ALLOWED_SORTS[iSortIndex])
			return 1

		return 0
