## Sid Meier's Civilization 4
## Copyright Firaxis Games 2005
from CvPythonExtensions import *
import CvUtil
import ScreenInput
import CvScreenEnums

# globals
gc = CyGlobalContext()
ArtFileMgr = CyArtFileMgr()
localText = CyTranslator()

class CvPediaSpell:
	"Civilopedia Screen for Spells"

	def __init__(self, main):
		self.iSpell = -1
		self.top = main

		self.BUTTON_SIZE = 46

		self.X_UNIT_PANE = 50
		self.Y_UNIT_PANE = 80
		self.W_UNIT_PANE = 250
		self.H_UNIT_PANE = 210

		self.X_ICON = 98
		self.Y_ICON = 110
		self.W_ICON = 150
		self.H_ICON = 150
		self.ICON_SIZE = 64

		self.X_PREREQ_PANE = 330
		self.Y_PREREQ_PANE = 60
		self.W_PREREQ_PANE = 420
		self.H_PREREQ_PANE = 110

		self.X_HELP_PANE = 330
		self.Y_HELP_PANE = 180
		self.W_HELP_PANE = self.W_PREREQ_PANE
		self.H_HELP_PANE = 110

		self.X_SPECIAL_PANE = 50 #330
		self.Y_SPECIAL_PANE = 294
		self.W_SPECIAL_PANE = self.W_PREREQ_PANE + (330-50)
		self.H_SPECIAL_PANE = 380

		self.FILTERS =	[
			{
				"name" : "UnFiltered",		# Name of the filter as it appears in dropdown menu.  Needs to be unique for this screen
				"Purpose" : "Clears all currently active filters",		# Description for the sanity of those who modify this file, appears and is used nowhere else
				"Hardcoded" : False,		# If this is True, then only those items in the HardcodeList will pass the check
				"HardcodeList" : [],
				"Value to Check" : 'None',	# Note that eSpell is the SpellInfo object being tested
				"Desired Result" : 'None',
			},
			{
				"name" : "World Spells",
				"Purpose" : "Global Spells",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'eSpell.isGlobal()',
				"Desired Result" : 'True',
			},
			{
				"name" : "Abilities",
				"Purpose" : "Spells unaffected by Arcane Lacuna",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'eSpell.isAbility()',
				"Desired Result" : 'True',
			},
			{
				"name" : "Summon Spells",
				"Purpose" : "Spells that create units (by non-python methods",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'eSpell.getCreateUnitType() != -1',
				"Desired Result" : 'True',
			},
			{
				"name" : "Divine Spells",
				"Purpose" : "Spells granted by the Divine promotion",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'eSpell.getPromotionPrereq1()',
				"Desired Result" : 'gc.getInfoTypeForString("PROMOTION_DIVINE")',
			},
			{
				"name" : "Air Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_FAIR_WINDS',
					'SPELL_MAELSTROM',
					'SPELL_SUMMON_AIR_ELEMENTAL'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Body Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_HASTE',
					'SPELL_REGENERATION',
					'SPELL_GRAFT_FLESH'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Chaos Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_DANCE_OF_BLADES',
					'SPELL_MUTATION',
					'SPELL_WONDER'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Creation Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_GROWTH',
					'SPELL_FERTILITY',
					'SPELL_BIRTH'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Death Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_RAISE_SKELETON',
					'SPELL_SUMMON_SPECTRE',
					'SPELL_SUMMON_WRAITH',
					'SPELL_LICHDOM'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Dimensional Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_ESCAPE',
					'SPELL_GATE'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Earth Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_WALL_OF_STONE',
					'SPELL_STONESKIN',
					'SPELL_SUMMON_EARTH_ELEMENTAL'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Enchantment Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_ENCHANTED_BLADE',
					'SPELL_FLAMING_ARROWS',
					'SPELL_ENCHANT_SPELLSTAFF'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Entropy Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_RUST',
					'SPELL_SUMMON_PIT_BEAST',
					'SPELL_WITHER'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Fire Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_BLAZE',
					'SPELL_FIREBALL',
					'SPELL_SUMMON_FIRE_ELEMENTAL'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Force Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_ACCELERATE',
					'SPELL_WALL_OF_FORCE'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Ice Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_SLOW',
					'SPELL_SUMMON_ICE_ELEMENTAL',
					'SPELL_FROZEN_LANDS'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Law Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_LOYALTY',
					'SPELL_SUMMON_EINHERJAR',
					'SPELL_VALOR'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Life Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_SANCTIFY',
					'SPELL_DESTROY_UNDEAD',
					'SPELL_RESSURECTION'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Metamagic Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_FLOATING_EYE',
					'SPELL_DISPEL_MAGIC',
					'SPELL_SUMMON_DJINN'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Mind Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_INSPIRATION',
					'SPELL_CHARM_PERSON',
					'SPELL_DOMINATION'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Nature Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_TREETOP_DEFENCE',
					'SPELL_POISONED_BLADE',
					'SPELL_VITALIZE'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Shadow Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_BLUR',
					'SPELL_SHADOWWALK',
					'SPELL_SUMMON_MISTFORM'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Spirit Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_COURAGE',
					'SPELL_HOPE',
					'SPELL_TRUST'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Sun Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_SCORCH',
					'SPELL_BLINDING_LIGHT',
					'SPELL_SUMMON_AUREALIS'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			{
				"name" : "Water Spellsphere",
				"Purpose" : "Ok, this is more annoying that sorting units by Civilization...",
				"Hardcoded" : True,
				"HardcodeList" : [
					'SPELL_SPRING',
					'SPELL_WATER_WALKING',
					'SPELL_SUMMON_WATER_ELEMENTAL'],
				"Value to Check" : 'None',
				"Desired Result" : 'None',
			},
			]

		# List the filters which you want to be available initially, or self.FILTERS to have all of them available from the start
		self.ALLOWED_FILTERS = self.FILTERS
		self.CURRENT_FILTER = self.FILTERS[0]

		self.SORTS =	[
			{
				"name" : "Sort by Alphabet",
				"Purpose" : "Default Sorting Method",
				"Value to Sort" : 'eSpell.getDescription()',
			},
			{
				"name" : "Sort by XML Order",
				"Purpose" : "Default, unsorted method",
				"Value to Sort" : None,		# Still provides eSpell as the value being tested
			},
			]

		# List the sorts which you want to be available initially, or self.SORTS to have all of them available from the start
		self.ALLOWED_SORTS = self.SORTS
		self.CURRENT_SORT = self.SORTS[0]
		self.SUB_SORT = self.SORTS[0]

	# Screen construction function
	def interfaceScreen(self, iSpell):
		self.iSpell = iSpell

		self.top.deleteAllWidgets()

		screen = self.top.getScreen()

		bNotActive = (not screen.isActive())
		if bNotActive:
			self.top.setPediaCommonWidgets()

		#Filter/Sort dropdowns
		self.top.FILTER_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.FILTER_DROPDOWN_ID, 22, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, filter in enumerate(self.ALLOWED_FILTERS):
			screen.addPullDownString(self.top.FILTER_DROPDOWN_ID, filter["name"], i, i, filter == self.CURRENT_FILTER )

		self.top.SORT_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.SORT_DROPDOWN_ID, 700, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, sort in enumerate(self.ALLOWED_SORTS):
			screen.addPullDownString(self.top.SORT_DROPDOWN_ID, sort["name"], 1, 1, sort == self.CURRENT_SORT )

		# Header...
		szHeader = u"<font=4b>" + gc.getSpellInfo(self.iSpell).getDescription().upper() + u"</font>"
		szHeaderId = self.top.getNextWidgetName()
		screen.setLabel(szHeaderId, "Background", szHeader, CvUtil.FONT_CENTER_JUSTIFY, self.top.X_SCREEN, self.top.Y_TITLE, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_GENERAL, -1, -1)

		# Top
		screen.setText(self.top.getNextWidgetName(), "Background", self.top.MENU_TEXT, CvUtil.FONT_LEFT_JUSTIFY, self.top.X_MENU, self.top.Y_MENU, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_SPELL, -1)

		if self.top.iLastScreen	!= CvScreenEnums.PEDIA_SPELL or bNotActive:
			self.placeLinks(true)
			self.top.iLastScreen = CvScreenEnums.PEDIA_SPELL
		else:
			self.placeLinks(false)

		# Icon
		screen.addPanel( self.top.getNextWidgetName(), "", "", False, False,
			self.X_UNIT_PANE, self.Y_UNIT_PANE, self.W_UNIT_PANE, self.H_UNIT_PANE, PanelStyles.PANEL_STYLE_BLUE50)
		screen.addPanel(self.top.getNextWidgetName(), "", "", false, false,
			self.X_ICON, self.Y_ICON, self.W_ICON, self.H_ICON, PanelStyles.PANEL_STYLE_MAIN)
		screen.addDDSGFC(self.top.getNextWidgetName(), gc.getSpellInfo(self.iSpell).getButton(),
			self.X_ICON + self.W_ICON/2 - self.ICON_SIZE/2, self.Y_ICON + self.H_ICON/2 - self.ICON_SIZE/2, self.ICON_SIZE, self.ICON_SIZE, WidgetTypes.WIDGET_GENERAL, -1, -1 )
#		screen.addDDSGFC(self.top.getNextWidgetName(), gc.getSpellInfo(self.iSpell).getButton(), self.X_ICON, self.Y_ICON, self.W_ICON, self.H_ICON, WidgetTypes.WIDGET_GENERAL, self.iSpell, -1 )

		# Place Required promotions
		self.placePrereqs()

		# Place Allowing promotions
		self.placeHelp()

		# Place the Special abilities block
		self.placeEffects()

		#self.placeUnitGroups()

	# Place prereqs...
	def placePrereqs(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_REQUIRES", ()), "", false, true,
				 self.X_PREREQ_PANE, self.Y_PREREQ_PANE, self.W_PREREQ_PANE, self.H_PREREQ_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		screen.attachLabel(panelName, "", "  ")

		ePromo = gc.getSpellInfo(self.iSpell).getPromotionPrereq1()
		if (ePromo > -1):
			screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromo).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromo, 1, False )

			ePromo = gc.getSpellInfo(self.iSpell).getPromotionPrereq2()
			if (ePromo > -1):
				screen.attachTextGFC(panelName, "", localText.getText("TXT_KEY_AND", ()), FontTypes.GAME_FONT, WidgetTypes.WIDGET_GENERAL, -1, -1)
				screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromo).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromo, 1, False )

	def placeHelp(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_HELP", ()), "", false, true,
				 self.X_HELP_PANE, self.Y_HELP_PANE, self.W_HELP_PANE, self.H_HELP_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		screen.attachLabel(panelName, "", "  ")
		listName = self.top.getNextWidgetName()

		szSpecialText = CyGameTextMgr().getSpellHelp(self.iSpell, True)[1:]

		screen.addMultilineText(listName, szSpecialText, self.X_HELP_PANE+5, self.Y_HELP_PANE+30, self.W_HELP_PANE-10, self.H_HELP_PANE-35, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY)

	def placeEffects(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_SPELL_EFFECTS", ()), "", true, false,
				 self.X_SPECIAL_PANE, self.Y_SPECIAL_PANE, self.W_SPECIAL_PANE, self.H_SPECIAL_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		listName = self.top.getNextWidgetName()

		pediaText = gc.getSpellInfo(self.iSpell).getCivilopedia()

		screen.addMultilineText(listName, pediaText, self.X_SPECIAL_PANE+5, self.Y_SPECIAL_PANE+30, self.W_SPECIAL_PANE-10, self.H_SPECIAL_PANE-35, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY)

	def placeLinks(self, bRedraw):
		screen = self.top.getScreen()

		if bRedraw:
			screen.clearListBoxGFC(self.top.LIST_ID)

		listSorted = self.getSortedList()

		i = 0
		iSelected = 0
		for iI in range(len(listSorted)):
			iSpell = listSorted[iI][2]
			szName = listSorted[iI][3]
			if bRedraw:
				screen.appendListBoxString(self.top.LIST_ID, szName, WidgetTypes.WIDGET_PEDIA_JUMP_TO_SPELL, iSpell, -1, CvUtil.FONT_LEFT_JUSTIFY)
			if iSpell == self.iSpell:
				iSelected = i
			i += 1

		screen.setSelectedListBoxStringGFC(self.top.LIST_ID, iSelected)

	def getSortedList(self):
		listSpells = []
		iCount = 0
		for iSpell in range(gc.getNumSpellInfos()):
			eSpell = gc.getSpellInfo(iSpell)
			if not eSpell.isGraphicalOnly():
				if self.CURRENT_FILTER["Hardcoded"]:
					for spell in self.CURRENT_FILTER["HardcodeList"]:
						if iSpell == gc.getInfoTypeForString(spell):
							listSpells.append(iSpell)
							iCount += 1
				elif eval(self.CURRENT_FILTER["Value to Check"]) == eval(self.CURRENT_FILTER["Desired Result"]):
					listSpells.append(iSpell)
					iCount += 1

		listSorted = [(0,0,0,0,0,0)] * iCount
		iI = 0
		for iSpell in listSpells:
			eSpell = gc.getSpellInfo(iSpell)
			sort1 = 0
			sort2 = 0
			if not self.CURRENT_SORT["Value to Sort"] == None:
				sort1 = eval(self.CURRENT_SORT["Value to Sort"])
				if not self.SUB_SORT["Value to Sort"] == None:
					sort2 = eval(self.SUB_SORT["Value to Sort"])
			listSorted[iI] = (sort1, sort2, iSpell, eSpell.getDescription(), eSpell.getButton(), 1)
			iI += 1
		listSorted.sort()

		return listSorted

	def applyFilterSort(self, filter, sort):
		if not self.CURRENT_SORT == sort:
			self.SUB_SORT = self.CURRENT_SORT
			self.CURRENT_SORT = sort
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_SPELL, True)

		if not self.CURRENT_FILTER == filter:
			self.CURRENT_FILTER = filter
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_SPELL, True)

	# Will handle the input for this screen...
	def handleInput (self, inputClass):
		if (inputClass.getNotifyCode() == NotifyCode.NOTIFY_LISTBOX_ITEM_SELECTED):
			screen = self.top.getScreen()
			iFilterIndex = screen.getSelectedPullDownID(self.top.FILTER_DROPDOWN_ID)
			iSortIndex = screen.getSelectedPullDownID(self.top.SORT_DROPDOWN_ID)
			self.applyFilterSort(self.ALLOWED_FILTERS[iFilterIndex], self.ALLOWED_SORTS[iSortIndex])
			return 1

		return 0