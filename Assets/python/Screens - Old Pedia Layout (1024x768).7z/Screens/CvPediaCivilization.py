## Sid Meier's Civilization 4
## Copyright Firaxis Games 2005
from CvPythonExtensions import *
import CvUtil
import ScreenInput
import CvScreenEnums
import string

# globals
gc = CyGlobalContext()
ArtFileMgr = CyArtFileMgr()
localText = CyTranslator()

class CvPediaCivilization:
	"Civilopedia Screen for Civilizations"

	def __init__(self, main):
		self.iCivilization = -1
		self.top = main

# InterfaceUpgrade: Better Pedia - Modified by Grey Fox 04/18/2008
		self.SPACING = 20
		
		self.X_MAIN_PANE = 20
		self.Y_MAIN_PANE = 65
		self.W_MAIN_PANE = 170
		self.H_MAIN_PANE = 200 #Opera
		
		self.W_ICON = 96
		self.H_ICON = 96
		self.ICON_SIZE = 64
		
		self.X_ICON = self.X_MAIN_PANE + ((self.W_ICON - self.ICON_SIZE)) + 5
		self.Y_ICON = self.Y_MAIN_PANE + ((self.H_ICON - self.ICON_SIZE)/4) - 5 + 52
		
		self.X_LOGO = self.X_MAIN_PANE + self.W_MAIN_PANE + self.SPACING
		self.Y_LOGO = self.Y_MAIN_PANE + 6
		self.W_LOGO = 567
		self.H_LOGO = 194 #Opera
		
		self.X_TECH = self.X_MAIN_PANE
		self.Y_TECH = self.Y_MAIN_PANE + self.H_MAIN_PANE + 5
		self.W_TECH = 170
		self.H_TECH = 105

		self.X_LEADER = self.X_MAIN_PANE
		self.Y_LEADER = self.Y_TECH + self.H_TECH
		self.W_LEADER = self.W_TECH
		self.H_LEADER = self.H_TECH

		self.X_BUILDING = self.X_MAIN_PANE
		self.Y_BUILDING = self.Y_LEADER + self.H_TECH
		self.W_BUILDING = 235 
		self.H_BUILDING = self.H_TECH
		
		self.X_UNIT = self.X_MAIN_PANE
		self.Y_UNIT = self.Y_BUILDING + self.H_TECH
		self.W_UNIT = self.W_BUILDING
		self.H_UNIT = self.H_TECH
		
		self.X_XBUILDING = self.X_BUILDING + self.W_BUILDING + self.SPACING
		self.Y_XBUILDING = self.Y_BUILDING
		self.W_XBUILDING = self.W_BUILDING
		self.H_XBUILDING = self.H_TECH
		
		self.X_XUNIT = self.X_UNIT + self.W_UNIT + self.SPACING
		self.Y_XUNIT = self.Y_UNIT
		self.W_XUNIT = self.W_XBUILDING
		self.H_XUNIT = self.H_TECH
		
		self.X_EFFECTS = self.X_XBUILDING + self.W_XBUILDING + self.SPACING
		self.Y_EFFECTS = self.Y_BUILDING
		self.W_EFFECTS = self.W_BUILDING + 12
		self.H_EFFECTS = self.H_TECH * 2
		
		self.X_TEXT = self.X_MAIN_PANE + self.W_TECH + self.SPACING
		self.Y_TEXT = self.Y_MAIN_PANE + self.SPACING + self.H_LOGO -13
		self.W_TEXT = self.W_LOGO
		self.H_TEXT = 215
# InterfaceUpgrade: Better Pedia - End Modify

		self.FILTERS =	[
			{
				"name" : "UnFiltered",		# Name of the filter as it appears in dropdown menu.  Needs to be unique for this screen
				"Purpose" : "Clears all currently active filters",		# Description for the sanity of those who modify this file, appears and is used nowhere else
				"Hardcoded" : False,		# If this is True, then only those items in the HardcodeList will pass the check
				"HardcodeList" : [],
				"Value to Check" : 'None',	# Note that eCiv is the CivilizationInfo object being tested
				"Desired Result" : 'None',
			},
			]

		# List the filters which you want to be available initially, or self.FILTERS to have all of them available from the start
		self.ALLOWED_FILTERS = self.FILTERS
		self.CURRENT_FILTER = self.FILTERS[0]

		self.SORTS =	[
			{
				"name" : "Sort by Alphabet",
				"Purpose" : "Default Sorting Method",
				"Value to Sort" : 'eCiv.getDescription()',
			},
			{
				"name" : "Sort by XML Order",
				"Purpose" : "Default, unsorted method",
				"Value to Sort" : None,
			},
			]

		# List the sorts which you want to be available initially, or self.SORTS to have all of them available from the start
		self.ALLOWED_SORTS = self.SORTS
		self.CURRENT_SORT = self.SORTS[0]
		self.SUB_SORT = self.SORTS[0]

	# Screen construction function
	def interfaceScreen(self, iCivilization):
		self.iCivilization = iCivilization

		self.top.deleteAllWidgets()

		screen = self.top.getScreen()

		bNotActive = (not screen.isActive())
		if bNotActive:
			self.top.setPediaCommonWidgets()

		#Filter/Sort dropdowns
		self.top.FILTER_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.FILTER_DROPDOWN_ID, 22, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, filter in enumerate(self.ALLOWED_FILTERS):
			screen.addPullDownString(self.top.FILTER_DROPDOWN_ID, filter["name"], i, i, filter == self.CURRENT_FILTER )

		self.top.SORT_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.SORT_DROPDOWN_ID, 700, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, sort in enumerate(self.ALLOWED_SORTS):
			screen.addPullDownString(self.top.SORT_DROPDOWN_ID, sort["name"], 1, 1, sort == self.CURRENT_SORT )

		# Header...
		szHeader = u"<font=4b>" + gc.getCivilizationInfo(self.iCivilization).getDescription().upper() + u"</font>"
		szHeaderId = self.top.getNextWidgetName()
		screen.setLabel(szHeaderId, "Background", szHeader, CvUtil.FONT_CENTER_JUSTIFY, self.top.X_SCREEN, self.top.Y_TITLE, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_GENERAL, -1, -1)

		# Top
		screen.setText(self.top.getNextWidgetName(), "Background", self.top.MENU_TEXT, CvUtil.FONT_LEFT_JUSTIFY, self.top.X_MENU, self.top.Y_MENU, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_CIV, -1)

		if self.top.iLastScreen	!= CvScreenEnums.PEDIA_CIVILIZATION or bNotActive:
			self.placeLinks(true)
			self.top.iLastScreen = CvScreenEnums.PEDIA_CIVILIZATION
		else:
			self.placeLinks(false)

		# Icon
		screen.addPanel( self.top.getNextWidgetName(), "", "", False, False,
			self.X_MAIN_PANE, self.Y_MAIN_PANE, self.W_MAIN_PANE, self.H_MAIN_PANE, PanelStyles.PANEL_STYLE_BLUE50)
		screen.addPanel(self.top.getNextWidgetName(), "", "", false, false,
			self.X_ICON, self.Y_ICON, self.W_ICON, self.H_ICON, PanelStyles.PANEL_STYLE_MAIN)
		screen.addDDSGFC(self.top.getNextWidgetName(), ArtFileMgr.getCivilizationArtInfo(gc.getCivilizationInfo(self.iCivilization).getArtDefineTag()).getButton(),
			self.X_ICON + self.W_ICON/2 - self.ICON_SIZE/2, self.Y_ICON + self.H_ICON/2 - self.ICON_SIZE/2, self.ICON_SIZE, self.ICON_SIZE, WidgetTypes.WIDGET_GENERAL, -1, -1 )

# InterfaceUpgrade: Better Pedia - Modified by Grey Fox 04/18/2008
		# Logo
		if gc.getCivilizationInfo(self.iCivilization).getImage() != None:
			screen.addPanel( self.top.getNextWidgetName(), "", "", False, False,
				self.X_LOGO, self.Y_LOGO, self.W_LOGO, self.H_LOGO, PanelStyles.PANEL_STYLE_BLUE50)
			screen.addPanel(self.top.getNextWidgetName(), "", "", false, false,
				self.X_LOGO + self.W_LOGO/2 - 512/2 - 36/2, self.Y_LOGO + self.H_LOGO/2 - 128/2 - 36/2, 512 + 36, 128 + 36, PanelStyles.PANEL_STYLE_MAIN)
			screen.addDDSGFC(self.top.getNextWidgetName(), gc.getCivilizationInfo(self.iCivilization).getImage(),
				self.X_LOGO + self.W_LOGO/2 - 512/2, self.Y_LOGO + self.H_LOGO/2 - 128/2, 512, 128, WidgetTypes.WIDGET_GENERAL, -1, -1 )
# InterfaceUpgrade: Better Pedia - End Modify

		self.placeTech()
		self.placeBuilding()
		self.placeUnit()
		self.placeLeader()
		self.placeText()
		self.placeBlockedBuilding()
		self.placeBlockedUnit()
		self.placeEffects()

		return

	def placeTech(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_FREE_TECHS", ()), "", false, true,
				 self.X_TECH, self.Y_TECH, self.W_TECH, self.H_TECH, PanelStyles.PANEL_STYLE_BLUE50 )
		screen.attachLabel(panelName, "", "  ")

		for iTech in range(gc.getNumTechInfos()):
			if (gc.getCivilizationInfo(self.iCivilization).isCivilizationFreeTechs(iTech)):
				screen.attachImageButton( panelName, "", gc.getTechInfo(iTech).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_TECH, iTech, 1, False )

	def placeBuilding(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_UNIQUE_BUILDINGS", ()), "", false, true,
				self.X_BUILDING, self.Y_BUILDING, self.W_BUILDING, self.H_BUILDING, PanelStyles.PANEL_STYLE_BLUE50 )
		screen.attachLabel(panelName, "", "  ")

		for iBuilding in range(gc.getNumBuildingClassInfos()):
			iUniqueBuilding = gc.getCivilizationInfo(self.iCivilization).getCivilizationBuildings(iBuilding);
			iDefaultBuilding = gc.getBuildingClassInfo(iBuilding).getDefaultBuildingIndex();
			if (iDefaultBuilding > -1 and iUniqueBuilding > -1 and iDefaultBuilding != iUniqueBuilding) or (iUniqueBuilding > -1 and gc.getBuildingClassInfo(iBuilding).isUnique()):
				screen.attachImageButton( panelName, "", gc.getBuildingInfo(iUniqueBuilding).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_BUILDING, iUniqueBuilding, 1, False )

	def placeUnit(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_FREE_UNITS", ()), "", false, true,
				 self.X_UNIT, self.Y_UNIT, self.W_UNIT, self.H_UNIT, PanelStyles.PANEL_STYLE_BLUE50 )
		screen.attachLabel(panelName, "", "  ")

		for iUnit in range(gc.getNumUnitClassInfos()):
			iUniqueUnit = gc.getCivilizationInfo(self.iCivilization).getCivilizationUnits(iUnit);
			iDefaultUnit = gc.getUnitClassInfo(iUnit).getDefaultUnitIndex();
			if (iDefaultUnit > -1 and iUniqueUnit > -1 and iDefaultUnit != iUniqueUnit) or (iUniqueUnit > -1 and gc.getUnitClassInfo(iUnit).isUnique()):
				szButton = gc.getUnitInfo(iUniqueUnit).getButton()
				if self.top.iActivePlayer != -1:
					szButton = gc.getPlayer(self.top.iActivePlayer).getUnitButton(iUniqueUnit)
				screen.attachImageButton( panelName, "", szButton, GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT, iUniqueUnit, 1, False )

	def placeLeader(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_CONCEPT_LEADERS", ()), "", false, true,
				 self.X_LEADER, self.Y_LEADER, self.W_LEADER, self.H_LEADER, PanelStyles.PANEL_STYLE_BLUE50 )
		screen.attachLabel(panelName, "", "  ")

		for iLeader in range(gc.getNumLeaderHeadInfos()):
			civ = gc.getCivilizationInfo(self.iCivilization)
			if civ.isLeaders(iLeader):
				screen.attachImageButton( panelName, "", gc.getLeaderHeadInfo(iLeader).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_LEADER, iLeader, self.iCivilization, False )

# InterfaceUpgrade: Better Pedia - Added by Grey Fox 04/19/2008
	# def placeWorldspell(self):		
		# screen = self.top.getScreen()
		
		# panelName = self.top.getNextWidgetName()
		# screen.addPanel( panelName, localText.getText("TXT_KEY_WORLD_SPHERE", ()), "", false, true,
				 # self.X_WORLDSPELL, self.Y_WORLDSPELL, self.W_WORLDSPELL, self.H_WORLDSPELL, PanelStyles.PANEL_STYLE_BLUE50 )
		# screen.attachLabel(panelName, "", "  ")

		# for iSpell in range(gc.getNumSpellInfos()):
			# spell = gc.getSpellInfo(iSpell)
			# if spell.isGlobal() and spell.getCivilizationPrereq() == self.iCivilization:
				# screen.attachImageButton( panelName, "", gc.getSpellInfo(iSpell).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_SPELL, iSpell, self.iCivilization, False )
# InterfaceUpgrade: Better Pedia - End Add				
				
	def placeText(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, "", "", true, true,
				 self.X_TEXT, self.Y_TEXT, self.W_TEXT, self.H_TEXT, PanelStyles.PANEL_STYLE_BLUE50 )

# InterfaceUpgrade: Better Pedia - Added by Grey Fox 04/18/2008
		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, "", "", true, true,
				 self.X_TEXT+10, self.Y_TEXT+35, self.W_TEXT-20, self.H_TEXT-40, PanelStyles.PANEL_STYLE_EMPTY )
# InterfaceUpgrade: Better Pedia - End Add				 
				 
		szText = gc.getCivilizationInfo(self.iCivilization).getCivilopedia()
		screen.attachMultilineText( panelName, "Text", szText, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY)

	def placeBlockedBuilding(self):
		screen = self.top.getScreen()
		panelName = self.top.getNextWidgetName()
		screen.addPanel(panelName, localText.getText("TXT_KEY_MISC_CIV_BLOCKED_BUILDINGS", ()), "", False, True, self.X_XBUILDING, self.Y_XBUILDING, self.W_XBUILDING, self.H_XBUILDING, PanelStyles.PANEL_STYLE_BLUE50)
		screen.attachLabel(panelName, "", "  ")

		for iBuildingClass in range(gc.getNumBuildingClassInfos()):
			iUniqueBuilding = gc.getCivilizationInfo(self.iCivilization).getCivilizationBuildings(iBuildingClass);
			iDefaultBuilding = gc.getBuildingClassInfo(iBuildingClass).getDefaultBuildingIndex();
			if iDefaultBuilding != BuildingTypes.NO_BUILDING and not gc.getBuildingClassInfo(iBuildingClass).isUnique():
				if iUniqueBuilding == BuildingTypes.NO_BUILDING:
					szButton = gc.getBuildingInfo(iDefaultBuilding).getButton()
					screen.attachImageButton(panelName, "", szButton, GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_BUILDING, iDefaultBuilding, 1, False)

	def placeBlockedUnit(self):
		screen = self.top.getScreen()
		panelName = self.top.getNextWidgetName()
		screen.addPanel(panelName, localText.getText("TXT_KEY_MISC_CIV_BLOCKED_UNITS", ()), "", False, True, self.X_XUNIT, self.Y_XUNIT, self.W_XUNIT, self.H_XUNIT, PanelStyles.PANEL_STYLE_BLUE50)
		screen.attachLabel(panelName, "", "  ")
		
		for iUnitClass in range(gc.getNumUnitClassInfos()):
			iUniqueUnit = gc.getCivilizationInfo(self.iCivilization).getCivilizationUnits(iUnitClass);
			iDefaultUnit = gc.getUnitClassInfo(iUnitClass).getDefaultUnitIndex();
			if iDefaultUnit != UnitTypes.NO_UNIT and not gc.getUnitClassInfo(iUnitClass).isUnique():
				if iUniqueUnit == UnitTypes.NO_UNIT:
					szButton = gc.getUnitInfo(iDefaultUnit).getButton()
					screen.attachImageButton(panelName, "", szButton, GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT, iDefaultUnit, 1, False)
	
	def placeEffects(self):
	
		screen = self.top.getScreen()
		
		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_EFFECTS", ()), "", true, false,
				 self.X_EFFECTS, self.Y_EFFECTS, self.W_EFFECTS, self.H_EFFECTS, PanelStyles.PANEL_STYLE_BLUE50 )
		#screen.attachLabel(panelName, "", " ")

		szName = self.top.getNextWidgetName()
		szText = CyGameTextMgr().parseMoreCivInfos(self.iCivilization, False, True, True)
		screen.attachMultilineText( panelName, szName, szText, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY )
		
	def placeLinks(self, bRedraw):
		screen = self.top.getScreen()

		if bRedraw:
			screen.clearListBoxGFC(self.top.LIST_ID)

		listSorted = self.getSortedList()

		i = 0
		iSelected = 0
		for iI in range(len(listSorted)):
			iCiv = listSorted[iI][2]
			szName = listSorted[iI][3]
			if bRedraw:
				screen.appendListBoxString(self.top.LIST_ID, szName, WidgetTypes.WIDGET_PEDIA_JUMP_TO_CIV, iCiv, -1, CvUtil.FONT_LEFT_JUSTIFY)
			if iCiv == self.iCivilization:
				iSelected = i
			i += 1

		screen.setSelectedListBoxStringGFC(self.top.LIST_ID, iSelected)

	def getSortedList(self):
		listCivs = []
		iCount = 0
		for iCiv in range(gc.getNumCivilizationInfos()):
			eCiv = gc.getCivilizationInfo(iCiv)
			if not eCiv.isGraphicalOnly():
				if self.CURRENT_FILTER["Hardcoded"]:
					for civ in self.CURRENT_FILTER["HardcodeList"]:
						if iCiv == gc.getInfoTypeForString(civ):
							listCivs.append(iCiv)
							iCount += 1
				elif eval(self.CURRENT_FILTER["Value to Check"]) == eval(self.CURRENT_FILTER["Desired Result"]):
					listCivs.append(iCiv)
					iCount += 1

		listSorted = [(0,0,0,0,0,0)] * iCount
		iI = 0
		for iCiv in listCivs:
			eCiv = gc.getCivilizationInfo(iCiv)
			sort1 = 0
			sort2 = 0
			if not self.CURRENT_SORT["Value to Sort"] == None:
				sort1 = eval(self.CURRENT_SORT["Value to Sort"])
				if not self.SUB_SORT["Value to Sort"] == None:
					sort2 = eval(self.SUB_SORT["Value to Sort"])
			listSorted[iI] = (sort1, sort2, iCiv, eCiv.getDescription(), eCiv.getButton(), 1)
			iI += 1
		listSorted.sort()

		return listSorted

	def applyFilterSort(self, filter, sort):
		if not self.CURRENT_SORT == sort:
			self.SUB_SORT = self.CURRENT_SORT
			self.CURRENT_SORT = sort
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_CIV, True)

		if not self.CURRENT_FILTER == filter:
			self.CURRENT_FILTER = filter
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_CIV, True)

	# Will handle the input for this screen...
	def handleInput (self, inputClass):
		if (inputClass.getNotifyCode() == NotifyCode.NOTIFY_LISTBOX_ITEM_SELECTED):
			screen = self.top.getScreen()
			iFilterIndex = screen.getSelectedPullDownID(self.top.FILTER_DROPDOWN_ID)
			iSortIndex = screen.getSelectedPullDownID(self.top.SORT_DROPDOWN_ID)
			self.applyFilterSort(self.ALLOWED_FILTERS[iFilterIndex], self.ALLOWED_SORTS[iSortIndex])
			return 1

		return 0