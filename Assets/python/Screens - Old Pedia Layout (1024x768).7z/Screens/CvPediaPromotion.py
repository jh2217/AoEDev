## Sid Meier's Civilization 4
## Copyright Firaxis Games 2005
from CvPythonExtensions import *
import CvUtil
import ScreenInput
import CvScreenEnums

# globals
gc = CyGlobalContext()
ArtFileMgr = CyArtFileMgr()
localText = CyTranslator()

class CvPediaPromotion:
	"Civilopedia Screen for Promotions"

	def __init__(self, main):
		self.iPromotion = -1
		self.top = main

		self.BUTTON_SIZE = 46

		self.X_UNIT_PANE = 50
		self.Y_UNIT_PANE = 80
		self.W_UNIT_PANE = 250
		self.H_UNIT_PANE = 210

		self.X_ICON = 98
		self.Y_ICON = 110
		self.W_ICON = 150
		self.H_ICON = 150
		self.ICON_SIZE = 64

		self.X_PREREQ_PANE = 330
		self.Y_PREREQ_PANE = 60
		self.W_PREREQ_PANE = 420
		self.H_PREREQ_PANE = 110

		self.X_LEADS_TO_PANE = 330
		self.Y_LEADS_TO_PANE = 180
		self.W_LEADS_TO_PANE = self.W_PREREQ_PANE
		self.H_LEADS_TO_PANE = 110

		self.X_SPECIAL_PANE = 330
		self.Y_SPECIAL_PANE = 294
		self.W_SPECIAL_PANE = self.W_PREREQ_PANE
		self.H_SPECIAL_PANE = 380 - 4 -  self.H_LEADS_TO_PANE

		self.X_SPELL_PANE = self.X_PREREQ_PANE
		self.Y_SPELL_PANE = self.Y_SPECIAL_PANE + self.H_SPECIAL_PANE + 4
		self.W_SPELL_PANE = self.W_PREREQ_PANE
		self.H_SPELL_PANE = self.H_PREREQ_PANE

		self.X_UNIT_GROUP_PANE = 50
		self.Y_UNIT_GROUP_PANE = 294
		self.W_UNIT_GROUP_PANE = 250
		self.H_UNIT_GROUP_PANE = 380
		self.DY_UNIT_GROUP_PANE = 25

		self.FILTERS =	[
			{
				"name" : "UnFiltered",		# Name of the filter as it appears in dropdown menu.  Needs to be unique for this screen
				"Purpose" : "Clears all currently active filters",		# Description for the sanity of those who modify this file, appears and is used nowhere else
				"Hardcoded" : False,		# If this is True, then only those items in the HardcodeList will pass the check
				"HardcodeList" : [],
				"Value to Check" : 'None',	# Note that ePromotion is the PromotionInfo object being tested
				"Desired Result" : 'None',
			},
			{
				"name" : "Races",
				"Purpose" : "Racial promotions",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.isRace()',
				"Desired Result" : 'True',
			},
			{
				"name" : "Equipment",
				"Purpose" : "Gear promotions",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.isEquipment()',
				"Desired Result" : 'True',
			},
			{
				"name" : "Command System",
				"Purpose" : "Benevolence & Feedback Promotions as I originally dubbed them",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getNumMinionPromotions() > 0 or ePromotion.getNumCommanderPromotions() or ePromotion.getNumSlavePromotions() > 0 or ePromotion.getNumMasterPromotions()',
				"Desired Result" : 'True',
			},
			{
				"name" : "Effects",
				"Purpose" : "Non-purchased promotions",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getMinLevel() < 0 or ePromotion.isNoXP()',
				"Desired Result" : 'True',
			},
			{
				"name" : "City Augmentation Promotions",
				"Purpose" : "Promotions using the so far rarely exploited CityBonus system",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getNumCityBonuses() > 0',
				"Desired Result" : 'True',
			},
			{
				"name" : "Automatically acquired Promotions",
				"Purpose" : "I've wanted a section for these for so long...",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.isAutoAcquire()',
				"Desired Result" : 'True',
			},
			{
				"name" : "Animal Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_ANIMAL"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Arcane Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_ADEPT"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Archer Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_ARCHER"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Beast Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_BEAST"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Commander Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_COMMANDER"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Disciple Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_DISCIPLE"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Melee Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_MELEE"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Mounted Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_MOUNTED"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Naval Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_NAVAL"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Recon Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_RECON"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Siege Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_SIEGE"))',
				"Desired Result" : 'True',
			},
			{
				"name" : "Worker Promotions",
				"Purpose" : "Promotions available per unitcombat",
				"Hardcoded" : False,
				"HardcodeList" : [],
				"Value to Check" : 'ePromotion.getUnitCombat(gc.getInfoTypeForString("UNITCOMBAT_WORKER"))',
				"Desired Result" : 'True',
			},
			]

		# List the filters which you want to be available initially, or self.FILTERS to have all of them available from the start
		self.ALLOWED_FILTERS = self.FILTERS
		self.CURRENT_FILTER = self.FILTERS[0]

		self.SORTS =	[
			{
				"name" : "Sort by Alphabet",
				"Purpose" : "Default Sorting Method",
				"Value to Sort" : 'ePromotion.getDescription()',
			},
			{
				"name" : "Sort by XML Order",
				"Purpose" : "Default, unsorted method",
				"Value to Sort" : None,
			},
			]

		# List the sorts which you want to be available initially, or self.SORTS to have all of them available from the start
		self.ALLOWED_SORTS = self.SORTS
		self.CURRENT_SORT = self.SORTS[0]
		self.SUB_SORT = self.SORTS[0]

	# Screen construction function
	def interfaceScreen(self, iPromotion):
		self.iPromotion = iPromotion

		self.top.deleteAllWidgets()

		screen = self.top.getScreen()

		bNotActive = (not screen.isActive())
		if bNotActive:
			self.top.setPediaCommonWidgets()

		#Filter/Sort dropdowns
		self.top.FILTER_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.FILTER_DROPDOWN_ID, 22, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, filter in enumerate(self.ALLOWED_FILTERS):
			screen.addPullDownString(self.top.FILTER_DROPDOWN_ID, filter["name"], i, i, filter == self.CURRENT_FILTER )

		self.top.SORT_DROPDOWN_ID = self.top.getNextWidgetName()
		screen.addDropDownBoxGFC(self.top.SORT_DROPDOWN_ID, 700, 12, 300, WidgetTypes.WIDGET_GENERAL, -1, -1, FontTypes.GAME_FONT)
		for i, sort in enumerate(self.ALLOWED_SORTS):
			screen.addPullDownString(self.top.SORT_DROPDOWN_ID, sort["name"], 1, 1, sort == self.CURRENT_SORT )

		# Header...
		szHeader = u"<font=4b>" + gc.getPromotionInfo(self.iPromotion).getDescription().upper() + u"</font>"
		szHeaderId = self.top.getNextWidgetName()
		screen.setLabel(szHeaderId, "Background", szHeader, CvUtil.FONT_CENTER_JUSTIFY, self.top.X_SCREEN, self.top.Y_TITLE, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_GENERAL, -1, -1)

		# Top
		JumpTo = CivilopediaPageTypes.CIVILOPEDIA_PAGE_PROMOTION
		screen.setText(self.top.getNextWidgetName(), "Background", self.top.MENU_TEXT, CvUtil.FONT_LEFT_JUSTIFY, self.top.X_MENU, self.top.Y_MENU, 0, FontTypes.TITLE_FONT, WidgetTypes.WIDGET_PEDIA_MAIN, JumpTo, -1)

		CurrScreen = CvScreenEnums.PEDIA_PROMOTION
		if self.top.iLastScreen	!= CurrScreen or bNotActive:
			self.placeLinks(true)
			self.top.iLastScreen = CurrScreen
		else:
			self.placeLinks(false)

		# Icon
		screen.addPanel( self.top.getNextWidgetName(), "", "", False, False,
			self.X_UNIT_PANE, self.Y_UNIT_PANE, self.W_UNIT_PANE, self.H_UNIT_PANE, PanelStyles.PANEL_STYLE_BLUE50)
		screen.addPanel(self.top.getNextWidgetName(), "", "", false, false,
			self.X_ICON, self.Y_ICON, self.W_ICON, self.H_ICON, PanelStyles.PANEL_STYLE_MAIN)
		screen.addDDSGFC(self.top.getNextWidgetName(), gc.getPromotionInfo(self.iPromotion).getButton(),
			self.X_ICON + self.W_ICON/2 - self.ICON_SIZE/2, self.Y_ICON + self.H_ICON/2 - self.ICON_SIZE/2, self.ICON_SIZE, self.ICON_SIZE, WidgetTypes.WIDGET_GENERAL, -1, -1 )

		# Place Required promotions
		self.placePrereqs()

		# Place Allowing promotions
		self.placeLeadsTo()

		# Place the Special abilities block
		self.placeSpecial()

		self.placeSpells()

		self.placeUnitGroups()

	# Place Leads To...
	def placeLeadsTo(self):

		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_LEADS_TO", ()), "", false, true,
				 self.X_LEADS_TO_PANE, self.Y_LEADS_TO_PANE, self.W_LEADS_TO_PANE, self.H_LEADS_TO_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		screen.attachLabel(panelName, "", "  ")

		for j in range(gc.getNumPromotionInfos()):
			if not (gc.getPromotionInfo(j).isEffectProm()):
#				if (gc.getPromotionInfo(j).getPrereqPromotion() == self.iPromotion or gc.getPromotionInfo(j).getPrereqOrPromotion1() == self.iPromotion or gc.getPromotionInfo(j).getPrereqOrPromotion2() == self.iPromotion):
#					screen.attachImageButton( panelName, "", gc.getPromotionInfo(j).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, j, 1, False )
				for k in xrange(gc.getPromotionInfo(j).getNumPrereqPromotionORs()):
					if (gc.getPromotionInfo(j).getPrereqPromotionORs(k, False) == self.iPromotion):
						screen.attachImageButton( panelName, "", gc.getPromotionInfo(j).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, j, 1, False )
                                for k in xrange(gc.getPromotionInfo(j).getNumPrereqPromotionANDs()):
					if (gc.getPromotionInfo(j).getPrereqPromotionANDs(k, False) == self.iPromotion):
						screen.attachImageButton( panelName, "", gc.getPromotionInfo(j).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, j, 1, False )

	# Place prereqs...
	def placePrereqs(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_REQUIRES", ()), "", false, true,
				 self.X_PREREQ_PANE, self.Y_PREREQ_PANE, self.W_PREREQ_PANE, self.H_PREREQ_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		screen.attachLabel(panelName, "", "  ")

#		ePromo = gc.getPromotionInfo(self.iPromotion).getPrereqPromotion()
#		if (ePromo > -1):
#			if (gc.getPromotionInfo(ePromo).isEffectProm()):
#				ePromo = -1
#		if (ePromo > -1):
#			screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromo).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromo, 1, False )

		iPromotionORs = 0
		iPromotionANDs = 0
		bFirst = true
		for i in xrange(gc.getPromotionInfo(self.iPromotion).getNumPrereqPromotionANDs()):
			if (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionANDs(i, True) > 0):
				iPromotion = gc.getPromotionInfo(self.iPromotion).getPrereqPromotionANDs(i, False)
				if not gc.getPromotionInfo(iPromotion).isEffectProm():
					iPromotionANDs += 1
					if iPromotionANDs > 1:
						screen.attachLabel(panelName, "", localText.getText("TXT_KEY_AND", ()))
					screen.attachImageButton( panelName, "", gc.getPromotionInfo(iPromotion).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, iPromotion, 1, False )	
					if (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionANDs(i, True) > 1):
						screen.attachLabel(panelName, "", localText.getText("TXT_KEY_NUM_PROMOTIONS_REQUIRED", (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionANDs(i, True), )))
		for iPromotion in xrange(gc.getPromotionInfo(self.iPromotion).getNumPrereqPromotionORs()):
			if (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionORs(iPromotion, True) > 0):
				if not gc.getPromotionInfo(iPromotion).isEffectProm():
					iPromotionORs += 1
		if iPromotionORs > 0:
			if iPromotionANDs > 0:
				screen.attachLabel(panelName, "", localText.getText("TXT_KEY_AND", ()))
			if iPromotionORs > 1:
				screen.attachLabel(panelName, "", "(")
			for i in xrange(gc.getPromotionInfo(self.iPromotion).getNumPrereqPromotionORs()):
				if (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionORs(i, True) > 0):
					iPromotion = gc.getPromotionInfo(self.iPromotion).getPrereqPromotionORs(i, False)
					if not gc.getPromotionInfo(iPromotion).isEffectProm():
						if not bFirst:
							screen.attachLabel(panelName, "", localText.getText("TXT_KEY_OR", ()))
						else:
							bFirst = false
						screen.attachImageButton( panelName, "", gc.getPromotionInfo(iPromotion).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, iPromotion, 1, False )		
						if (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionORs(i, True) > 1):
							screen.attachLabel(panelName, "", localText.getText("TXT_KEY_NUM_PROMOTIONS_REQUIRED", (gc.getPromotionInfo(self.iPromotion).getPrereqPromotionORs(i, True), )))						
			if iPromotionORs > 1:
				screen.attachLabel(panelName, "", ")")						
			
#		ePromoOr1 = gc.getPromotionInfo(self.iPromotion).getPrereqOrPromotion1()
#		if (ePromoOr1 > -1):
#			if (gc.getPromotionInfo(ePromoOr1).isEffectProm()):
#				ePromoOr1 = -1
#		ePromoOr2 = gc.getPromotionInfo(self.iPromotion).getPrereqOrPromotion2()
#		if (ePromoOr2 > -1):
#			if (gc.getPromotionInfo(ePromoOr2).isEffectProm()):
#				ePromoOr2 = -1
#
#		ePromoAnd = gc.getPromotionInfo(self.iPromotion).getPromotionPrereqAnd()
#		if (ePromoAnd > -1):
#			if (gc.getPromotionInfo(ePromoAnd).isEffectProm()):
#				ePromoAnd = -1
#		ePromoOr3 = gc.getPromotionInfo(self.iPromotion).getPromotionPrereqOr3()
#		if (ePromoOr3 > -1):
#			if (gc.getPromotionInfo(ePromoOr3).isEffectProm()):
#				ePromoOr3 = -1
#		ePromoOr4 = gc.getPromotionInfo(self.iPromotion).getPromotionPrereqOr4()
#		if (ePromoOr4 > -1):
#			if (gc.getPromotionInfo(ePromoOr4).isEffectProm()):
#				ePromoOr4 = -1

#		if (ePromoAnd > -1):
#			if not (gc.getPromotionInfo(ePromoAnd).isEffectProm()):
#				screen.attachLabel(panelName, "", localText.getText("TXT_KEY_AND", ()))
#				screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromoAnd).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromoAnd, 1, False )
#
#		if (ePromoOr1 > -1):
#			if (ePromo > -1):
#				screen.attachLabel(panelName, "", localText.getText("TXT_KEY_AND", ()))
#
#				if (ePromoOr2 > -1):
#					screen.attachLabel(panelName, "", "(")
#
#			screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromoOr1).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromoOr1, 1, False )
#
#			if (ePromoOr2 > -1):
#				screen.attachLabel(panelName, "", localText.getText("TXT_KEY_OR", ()))
#				screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromoOr2).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromoOr2, 1, False )
#
#			if (ePromoOr3 > -1):
#				screen.attachLabel(panelName, "", localText.getText("TXT_KEY_OR", ()))
#				screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromoOr3).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromoOr3, 1, False )
#
#			if (ePromoOr4 > -1):
#				screen.attachLabel(panelName, "", localText.getText("TXT_KEY_OR", ()))
#				screen.attachImageButton( panelName, "", gc.getPromotionInfo(ePromoOr4).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, ePromoOr4, 1, False )
#
#			if (ePromoOr2 > -1):
#				screen.attachLabel(panelName, "", ")")
#
		eTech = gc.getPromotionInfo(self.iPromotion).getTechPrereq()
		if (eTech > -1):
			screen.attachImageButton( panelName, "", gc.getTechInfo(eTech).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_TECH, eTech, 1, False )

		eReligion = gc.getPromotionInfo(self.iPromotion).getStateReligionPrereq()
		if (eReligion > -1):
			screen.attachImageButton( panelName, "", gc.getReligionInfo(eReligion).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_RELIGION, eReligion, 1, False )

	def placeSpecial(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_SPECIAL_ABILITIES", ()), "", true, false,
				 self.X_SPECIAL_PANE, self.Y_SPECIAL_PANE, self.W_SPECIAL_PANE, self.H_SPECIAL_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		listName = self.top.getNextWidgetName()

		szSpecialText = CyGameTextMgr().getPromotionHelp(self.iPromotion, True)[1:]
		screen.addMultilineText(listName, szSpecialText, self.X_SPECIAL_PANE+5, self.Y_SPECIAL_PANE+30, self.W_SPECIAL_PANE-10, self.H_SPECIAL_PANE-35, WidgetTypes.WIDGET_GENERAL, -1, -1, CvUtil.FONT_LEFT_JUSTIFY)

	def placeUnitGroups(self):
		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_PROMOTION_UNITS", ()), "", true, true,
			self.X_UNIT_GROUP_PANE, self.Y_UNIT_GROUP_PANE, self.W_UNIT_GROUP_PANE, self.H_UNIT_GROUP_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		szTable = self.top.getNextWidgetName()
		screen.addTableControlGFC(szTable, 1,
			self.X_UNIT_GROUP_PANE + 10, self.Y_UNIT_GROUP_PANE + 40, self.W_UNIT_GROUP_PANE - 20, self.H_UNIT_GROUP_PANE - 50, False, False, 24, 24, TableStyles.TABLE_STYLE_EMPTY)

		i = 0
		for iI in range(gc.getNumUnitCombatInfos()):
			if (0 != gc.getPromotionInfo(self.iPromotion).getUnitCombat(iI)):
				iRow = screen.appendTableRow(szTable)
				screen.setTableText(szTable, 0, i, u"<font=2>" + gc.getUnitCombatInfo(iI).getDescription() + u"</font>", gc.getUnitCombatInfo(iI).getButton(), WidgetTypes.WIDGET_PEDIA_JUMP_TO_UNIT_COMBAT, iI, -1, CvUtil.FONT_LEFT_JUSTIFY)
				i += 1

	# Place Leads To...
	def placeSpells(self):

		screen = self.top.getScreen()

		panelName = self.top.getNextWidgetName()
		screen.addPanel( panelName, localText.getText("TXT_KEY_PEDIA_SPELLS (or LEADS_TO)", ()), "", false, true,
				 self.X_SPELL_PANE, self.Y_SPELL_PANE, self.W_SPELL_PANE, self.H_SPELL_PANE, PanelStyles.PANEL_STYLE_BLUE50 )

		screen.attachLabel(panelName, "", "  ")

		for j in range(gc.getNumSpellInfos()):
			iPrereq = gc.getSpellInfo(j).getPromotionPrereq1()
			if (iPrereq == self.iPromotion):
				screen.attachImageButton( panelName, "", gc.getSpellInfo(j).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_SPELL, j, 1, False )
			iPrereq = gc.getSpellInfo(j).getPromotionPrereq2()
			if (iPrereq == self.iPromotion):
				screen.attachImageButton( panelName, "", gc.getSpellInfo(j).getButton(), GenericButtonSizes.BUTTON_SIZE_CUSTOM, WidgetTypes.WIDGET_PEDIA_JUMP_TO_SPELL, j, 1, False )

	def placeLinks(self, bRedraw):
		screen = self.top.getScreen()

		if bRedraw:
			screen.clearListBoxGFC(self.top.LIST_ID)

		listSorted = self.getSortedList()

		i = 0
		iSelected = 0
		for iI in range(len(listSorted)):
			iPromotion = listSorted[iI][2]
			szName = listSorted[iI][3]
			if bRedraw:
				screen.appendListBoxString(self.top.LIST_ID, szName, WidgetTypes.WIDGET_PEDIA_JUMP_TO_PROMOTION, iPromotion, -1, CvUtil.FONT_LEFT_JUSTIFY)
			if iPromotion == self.iPromotion:
				iSelected = i
			i += 1

		screen.setSelectedListBoxStringGFC(self.top.LIST_ID, iSelected)

	def getSortedList(self):
		listPromotions = []
		iCount = 0
		for iPromotion in range(gc.getNumPromotionInfos()):
			ePromotion = gc.getPromotionInfo(iPromotion)
			if not ePromotion.isGraphicalOnly():
				if self.CURRENT_FILTER["Hardcoded"]:
					for promotion in self.CURRENT_FILTER["HardcodeList"]:
						if iPromotion == gc.getInfoTypeForString(promotion):
							listPromotions.append(iPromotion)
							iCount += 1
				elif eval(self.CURRENT_FILTER["Value to Check"]) == eval(self.CURRENT_FILTER["Desired Result"]):
					listPromotions.append(iPromotion)
					iCount += 1

		listSorted = [(0,0,0,0,0,0)] * iCount
		iI = 0
		for iPromotion in listPromotions:
			ePromotion = gc.getPromotionInfo(iPromotion)
			sort1 = 0
			sort2 = 0
			if not self.CURRENT_SORT["Value to Sort"] == None:
				sort1 = eval(self.CURRENT_SORT["Value to Sort"])
				if not self.SUB_SORT["Value to Sort"] == None:
					sort2 = eval(self.SUB_SORT["Value to Sort"])
			listSorted[iI] = (sort1, sort2, iPromotion, ePromotion.getDescription(), ePromotion.getButton(), 1)
			iI += 1
		listSorted.sort()

		return listSorted

	def applyFilterSort(self, filter, sort):
		if not self.CURRENT_SORT == sort:
			self.SUB_SORT = self.CURRENT_SORT
			self.CURRENT_SORT = sort
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_PROMOTION, True)

		if not self.CURRENT_FILTER == filter:
			self.CURRENT_FILTER = filter
			self.top.pediaJump(CvScreenEnums.PEDIA_MAIN, CivilopediaPageTypes.CIVILOPEDIA_PAGE_PROMOTION, True)

	# Will handle the input for this screen...
	def handleInput (self, inputClass):
		if (inputClass.getNotifyCode() == NotifyCode.NOTIFY_LISTBOX_ITEM_SELECTED):
			screen = self.top.getScreen()
			iFilterIndex = screen.getSelectedPullDownID(self.top.FILTER_DROPDOWN_ID)
			iSortIndex = screen.getSelectedPullDownID(self.top.SORT_DROPDOWN_ID)
			self.applyFilterSort(self.ALLOWED_FILTERS[iFilterIndex], self.ALLOWED_SORTS[iSortIndex])
			return 1

		return 0